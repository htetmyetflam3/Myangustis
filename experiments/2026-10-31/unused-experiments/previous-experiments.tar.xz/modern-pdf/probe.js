const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { performance } = require('node:perf_hooks');
const lib = require('modern-pdf-lib');
const [label,input,out] = process.argv.slice(2);
const bytes = fs.readFileSync(input);
const result = { label, inputBytes:bytes.length, node:process.version };
const h=(b)=>crypto.createHash('sha256').update(b).digest('hex');
(async () => {
 try {
  const started=performance.now();
  const doc=await lib.loadPdf(bytes);
  result.loadMs=Math.round(performance.now()-started);
  result.pages=doc.getPageCount();
  const page=doc.getPage(0);
  const startContent=performance.now();
  const content=page.getContentStream();
  const contentTime=performance.now()-startContent;
  result.page1={decodedBytes:content.length,sha256:h(content),decodeMs:Math.round(contentTime),
    hasResources:!!page.getOriginalResources?.(), contentRefs:page.getOriginalContentRefs?.().length??null,
    prefix300Bytes:Math.min(content.length,300)};
  try {result.page1.operators=lib.parseContentStream(content).length;}
  catch(e){result.page1.operatorsError=e.message;}
 } catch(e) {result.loadError=`${e.name}: ${e.message}`;}
 try {
  const t=performance.now();
  const output=await lib.linearizePdf(bytes);
  result.linearizeMs=Math.round(performance.now()-t);
  result.outputBytes=output.length;
  result.reportedLinearized=lib.isLinearized(output);
  fs.writeFileSync(out,output);
 } catch(e) {result.linearizeError=`${e.name}: ${e.message}`;}
 result.maxRssMiB=Math.round(process.resourceUsage().maxRSS/1024*10)/10;
 console.log(JSON.stringify(result));
})();
