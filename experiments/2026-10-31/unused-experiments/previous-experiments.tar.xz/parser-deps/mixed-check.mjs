import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {PDFDocument,StandardFonts} from 'pdf-lib';
import {createCanvas} from '@napi-rs/canvas';
import {streamPdfPages} from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
import {Manager} from '/home/user/Myangustis/B.Parser/main/parser/manager.js';
const doc=await PDFDocument.create();const canvas=createCanvas(40,40);const cx=canvas.getContext('2d');cx.fillStyle='white';cx.fillRect(0,0,40,40);cx.fillStyle='black';cx.fillText('body',1,20);const image=await doc.embedPng(canvas.toBuffer('image/png'));const font=await doc.embedFont(StandardFonts.Helvetica);
let p=doc.addPage([600,800]);p.drawImage(image,{x:3,y:4,width:594,height:792});p.drawText('Scanned by CamScanner',{x:40,y:12,size:10,font});
p=doc.addPage([600,800]);p.drawImage(image,{x:100,y:300,width:60,height:80});p.drawText('Existing vector text',{x:30,y:700,size:10,font});
p=doc.addPage([600,800]);p.drawText('Text only',{x:30,y:700,size:10,font});
const bytes=Buffer.from(await doc.save({useObjectStreams:false}));const file='/home/user/.cache/parser-eye/parser-deps/mixed.pdf';fs.writeFileSync(file,bytes);
const [,n,pages]=streamPdfPages(bytes); for(const page of pages) console.log('page',page.idx+1,JSON.stringify({text:page.text,images:page.images,hasImg:page.hasImg}));
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'manual-mixed-check-'));const m=new Manager({outputDir:dir});const calls=[];
m._dispatchOcr=async payload=>{calls.push({type:payload.type,page:payload.pageNumber,bbox:payload.bbox,path:payload.inPath,exists:fs.existsSync(payload.inPath)});return payload.type==='ocrPage'?'BODY OCR\nScanned by CamScanner':'IMAGE LABEL'};
try {const r=await m.dispatch({job:'extracting',method:'manual',output:'txt',inputKind:'pdf',inPath:file,filename:'mixed.pdf',applyCleanup:false,includeText:true});console.log('calls',JSON.stringify(calls));console.log('result',JSON.stringify({pages:r.pages,ocrPages:r.ocrPages,text:r.text,warning:r.linearizationWarning}));console.log('temporary sources deleted',calls.every(c=>!fs.existsSync(c.path)));} finally{await m.close();fs.rmSync(dir,{recursive:true,force:true})}
