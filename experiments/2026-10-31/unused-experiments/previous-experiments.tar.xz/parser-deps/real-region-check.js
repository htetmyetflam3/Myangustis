import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';
import {PDFDocument,StandardFonts} from 'pdf-lib';
import {Manager} from '/home/user/Myangustis/B.Parser/main/parser/manager.js';
import {streamPdfPages} from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
const pdf=await PDFDocument.create();const page=pdf.addPage([600,800]);
const image=await pdf.embedPng(fs.readFileSync('/home/user/.cache/parser-eye/grammar-audit-150.png'));
const font=await pdf.embedFont(StandardFonts.Helvetica);
page.drawImage(image,{x:50,y:250,width:486,height:348});
page.drawText('Original vector text',{x:50,y:720,size:14,font});
page.drawText('Vector footer remains',{x:50,y:28,size:10,font});
const bytes=Buffer.from(await pdf.save({useObjectStreams:false}));
const [,,pages]=streamPdfPages(bytes);const record=pages.next().value;assert.equal(record.images.length,1);assert.equal(record.images[0].pageSized,false);assert.ok(record.text.includes('Original vector text'));
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parser-region-'));const manager=new Manager({outputDir:dir});
try{const result=await manager.dispatch({job:'extracting',method:'manual',output:'txt',inputKind:'pdf',data:bytes,filename:'mixed-region.pdf',applyCleanup:false,includeText:true});
 assert.equal(result.action,'parse');assert.deepEqual(result.ocrPages,[1]);assert.ok(result.text.includes('Original vector text'));assert.ok(result.text.includes('Vector footer remains'));
 const myanmar=(result.text.match(/[\u1000-\u109f]/gu)||[]).length;assert.ok(myanmar>=10,`Expected real Burmese OCR; got ${myanmar}`);assert.ok(!result.linearizationWarning);
 console.log(JSON.stringify({imageCoverage:record.images[0].coverage,bbox:record.images[0].bbox,ocrPages:result.ocrPages,myanmarCodepoints:myanmar,vectorTextPreserved:true,ocrExcerpt:result.text.split('\n').filter(line=>/[\u1000-\u109f]/u.test(line)).slice(0,2)}));
}finally{await manager.close();fs.rmSync(dir,{recursive:true,force:true});}
