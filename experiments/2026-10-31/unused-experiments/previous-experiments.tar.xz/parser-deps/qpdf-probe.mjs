import fs from 'node:fs';
import createQpdf from './node_modules/qpdf-wasm-esm-embedded/qpdf.mjs';
const input = process.argv[2]; const output = process.argv[3];
const errors=[];
const q=await createQpdf({noInitialRun: true, print:()=>{}, printErr:(s)=>errors.push(s)});
q.FS.writeFile('/input.pdf',fs.readFileSync(input));
const status=q.callMain(['--linearize','--object-streams=disable','/input.pdf','/out.pdf']);
console.log({status, errors}); fs.writeFileSync(output,q.FS.readFile('/out.pdf'));
