const fs = require('node:fs');
const createQpdf=require('@jspawn/qpdf-wasm');
(async ()=>{
 const errors=[];
 const q = await createQpdf({ noInitialRun:true, instantiateWasm:(imports,done)=>{WebAssembly.instantiate(fs.readFileSync(require.resolve('@jspawn/qpdf-wasm/qpdf.wasm')),imports).then(({instance})=>done(instance));return {}}, print:()=>{}, printErr:s=>errors.push(s) });
 q.FS.writeFile('/input.pdf', fs.readFileSync(process.argv[2]));
 const status=q.callMain(['--linearize','--object-streams=disable','/input.pdf','/out.pdf']);
 console.log({status, errors}); fs.writeFileSync(process.argv[3],q.FS.readFile('/out.pdf'));
})().catch(e=>{console.error(e);process.exitCode=1});
