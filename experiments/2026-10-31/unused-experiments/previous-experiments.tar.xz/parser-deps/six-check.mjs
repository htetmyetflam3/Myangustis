import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {processBytesForMethod,streamPdfPages,loadDetector} from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
const cases=[
 ['zawgyi','/home/user/.cache/parser-eye/refs/sample.pdf'],
 ['unicode','/home/user/Myangustis/Junk/Parser/upload/keyboards/font-replay/compact-zawcode-stack-samples.pdf'],
 ['bg1','/home/user/.cache/parser-eye/refs/bg-mlc-1-1.pdf'],
 ['bg2','/home/user/.cache/parser-eye/refs/bg-mlc-2-5.pdf'],
 ['grammar','/home/user/.cache/parser-eye/refs/mm-grammar.pdf'],
 ['yeynin','/home/user/.cache/parser-eye/refs/ယဲ့နင် စာစဉ် a ၁.merged.merged.pdf'],
];
for (const [name,file] of cases) {
 const started=performance.now(); let job;
 try {
  const input=fs.readFileSync(file);
  job=await processBytesForMethod(input,'pdf','default',loadDetector(),name,()=>{}, {retainLinearizedSource:true});
  if (!job.internalPdf) throw new Error(`linearization failed: ${job.linearizationError}`);
  fs.copyFileSync(job.internalPdf.path,`/home/user/.cache/parser-eye/parser-deps/six-${name}.pdf`);
  const finished=performance.now(); const [,n,pages]=streamPdfPages(job.internalPdf.path,loadDetector());
  let compared=0,different=0,markers=0,points=0,images=0,paths={};
  for (const pg of pages) {
    const a=job.pages[pg.idx]?.text??''; if(a!==pg.text)different++;
    compared++; markers+=(pg.text.match(/\[[0-9A-F]{2,8}\]/g)||[]).length;
    points+=(pg.text.match(/[\u1000-\u109f]/gu)||[]).length; images+=pg.images.length;
    paths[pg.parsingPath]=(paths[pg.parsingPath]||0)+1;
  }
  console.log(JSON.stringify({name,pages:job.npages,compared,different,paths,counts:job.counts,myanmarPoints:points,unresolvedMarkers:markers,paintedImages:images,sourceBytes:input.length,linearizedBytes:fs.statSync(job.internalPdf.path).size,processSeconds:+((finished-started)/1000).toFixed(3),compareSeconds:+((performance.now()-finished)/1000).toFixed(3),rssMiB:+(process.memoryUsage().rss/1048576).toFixed(1)}));
 } catch(e){console.log(JSON.stringify({name,error:e.message,stack:e.stack}));process.exitCode=1;}
 finally {if(job?.internalPdf?.dir)fs.rmSync(job.internalPdf.dir,{recursive:true,force:true})}
}
