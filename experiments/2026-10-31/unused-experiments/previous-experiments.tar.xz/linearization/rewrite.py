import hashlib, json, os, resource, sys, time
from pathlib import Path
import pikepdf
src, dst, report = map(Path, sys.argv[1:4])
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()
t0 = time.perf_counter()
usage0 = resource.getrusage(resource.RUSAGE_SELF)
with pikepdf.open(src) as pdf:
    pages = len(pdf.pages)
    was_linearized = bool(pdf.is_linearized)
    pdf.save(dst, linearize=True, object_stream_mode=pikepdf.ObjectStreamMode.disable)
elapsed = time.perf_counter() - t0
usage1 = resource.getrusage(resource.RUSAGE_SELF)
with pikepdf.open(dst) as pdf:
    actual = {'pages': len(pdf.pages), 'linearized': bool(pdf.is_linearized), 'check': bool(pdf.check_linearization())}
row = {
    'source': str(src), 'output': str(dst), 'beforeBytes': src.stat().st_size,
    'afterBytes': dst.stat().st_size, 'sha256Before': digest(src), 'sha256After': digest(dst),
    'sourcePages': pages, 'wasLinearized': was_linearized, 'result': actual,
    'seconds': round(elapsed, 4), 'cpuSeconds': round((usage1.ru_utime+usage1.ru_stime)-(usage0.ru_utime+usage0.ru_stime),4),
    'peakMiB': round(usage1.ru_maxrss / 1024, 1), 'pikepdf': pikepdf.__version__, 'libqpdf': pikepdf.__libqpdf_version__,
}
report.write_text(json.dumps(row, ensure_ascii=False, indent=2))
print(json.dumps(row, ensure_ascii=False), flush=True)
