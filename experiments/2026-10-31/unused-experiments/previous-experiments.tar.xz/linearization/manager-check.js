import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const {Manager}=await import(pathToFileURL(path.resolve('B.Parser/main/parser/manager.js')).href);
const dir=await fs.mkdtemp(path.join(os.tmpdir(),'parser-linear-compare-'));
const manager=new Manager({outputDir:dir});
const checks=[
 ['bg1 original site','/home/user/.cache/parser-eye/refs/bg-mlc-1-1.pdf','site'],
 ['bg1 linearized site','/home/user/.cache/parser-eye/linearization/bg1.pdf','site'],
 ['bg1 original scraper','/home/user/.cache/parser-eye/refs/bg-mlc-1-1.pdf','scraper'],
 ['bg1 linearized scraper','/home/user/.cache/parser-eye/linearization/bg1.pdf','scraper'],
 ['unicode original site','Junk/Parser/upload/keyboards/font-replay/compact-zawcode-stack-samples.pdf','site'],
 ['unicode linearized site','/home/user/.cache/parser-eye/linearization/unicode.pdf','site'],
];
try {
 for(const [label,file,who] of checks) {
  try {
   const r=await manager.dispatch({job:'extracting',method:'default',output:'txt',inputKind:'pdf',inPath:path.resolve(file),filename:path.basename(file),applyCleanup:false,includeText:true},who);
   console.log(JSON.stringify({label,caller:r.caller,skipped:r.skipped,reason:r.reason??null,pages:r.pages,textChars:r.textChars,counts:r.counts,encodingPath:r.encodingPath,sha256:typeof r.text==='string'?createHash('sha256').update(r.text).digest('hex'):null}));
  } catch(e) {console.log(JSON.stringify({label,error:e.message}));}
 }
} finally { await manager.close(); await fs.rm(dir,{recursive:true,force:true}); }
