import fs from 'node:fs'; import path from 'node:path'; import {performance} from 'node:perf_hooks'; import {pathToFileURL} from 'node:url';
const {streamPdfPages,loadDetector}=await import(pathToFileURL(path.resolve('B.Parser/extend/pipeline.js')).href);
const file=process.argv[2], data=fs.readFileSync(file), t0=performance.now();
const [,total,pages]=streamPdfPages(data,loadDetector()); const initialized=performance.now();
const page=pages.next().value; const complete=performance.now();
console.log(JSON.stringify({file:path.basename(file),pages:total,initializeMs:Math.round(initialized-t0),firstPageMs:Math.round(complete-t0),firstChars:page.text.length, maxRssMiB:Math.round(process.resourceUsage().maxRSS/1024*10)/10}));
