import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { pathToFileURL } from 'node:url';
const [input, output, preservedSource] = process.argv.slice(2);
const modulePath=pathToFileURL(path.resolve('B.Parser/extend/pipeline.js')).href;
const {loadDetector,processBytesForMethod}=await import(modulePath);
let sourceIdentity = null;
if (preservedSource) {
 const {DocumentDecoding}=await import(pathToFileURL(path.resolve('B.Parser/main/parser/read/pdf-fonts.js')).href);
 sourceIdentity=createHash('sha256').update(fs.readFileSync(preservedSource)).digest('hex');
 Object.defineProperty(DocumentDecoding.prototype,'documentSha256',{
  configurable:true,
  set(rewrittenDigest){ this._rewrittenDigest=rewrittenDigest; },
  get(){ return sourceIdentity; },
 });
}
const started=performance.now();
const original=fs.readFileSync(input);
const readMs=performance.now()-started;
const cpu0=process.cpuUsage();
const startParse=performance.now();
const job=await processBytesForMethod(original, 'pdf', 'default', loadDetector(), path.basename(input));
const parseMs=performance.now()-startParse;
const cpu=process.cpuUsage(cpu0);
const digest=t=>createHash('sha256').update(t,'utf8').digest('hex');
let markerTokens=0, myanmarPoints=0, asciiLetters=0, textBytes=0, lineCount=0;
const pageInfo=[];
for (let i=0;i<job.pages.length;i++) {
 const page=job.pages[i], t=page.text??'', markers=[...t.matchAll(/\[(?:[0-9A-F]{2,8})\]/gu)].length;
 const myanmar=[...t.matchAll(/[\u1000-\u109F\uA9E0-\uA9FF\uAA60-\uAA7F]/gu)].length;
 const latin=[...t.matchAll(/[A-Za-z]/gu)].length;
 const bytes=Buffer.byteLength(t,'utf8');
 const lines=Array.isArray(page.lines)?page.lines.length:(t?t.split('\n').length:0);
 markerTokens+=markers; myanmarPoints+=myanmar; asciiLetters+=latin; textBytes+=bytes; lineCount+=lines;
 pageInfo.push({hash:digest(t), chars:t.length, bytes, lines, markers, myanmar, asciiLetters:latin, category:job.reports[i]?.category??null});
}
const result={ input, sourceIdentity, inputBytes:original.length, pageCount:job.pages.length, counts:job.counts,
 totals:{textBytes,lineCount,markerTokens,myanmarPoints,asciiLetters},
 timing:{readMs:Math.round(readMs),parseMs:Math.round(parseMs),cpuMs:Math.round((cpu.user+cpu.system)/1000)},
 memory:{maxRssMiB:Math.round(process.resourceUsage().maxRSS/1024*10)/10}, pageInfo };
fs.writeFileSync(output,JSON.stringify(result));
console.log(JSON.stringify({...result,pageInfo:undefined}));
