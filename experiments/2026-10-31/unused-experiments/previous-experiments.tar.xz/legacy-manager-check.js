import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { Manager } from '/home/user/Myangustis/B.Parser/main/parser/manager.js';
import { extractDocxParagraphs } from '/home/user/Myangustis/B.Parser/main/parser/read/docx-extract.js';
import { streamPdfPages } from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
const source='/home/user/.cache/parser-eye/legacy-grammar-page150.pdf';
const pre=JSON.parse(fs.readFileSync('/home/user/.cache/parser-eye/legacy-normalize-before.json','utf8')).find(x=>x.name==='grammar'&&x.page===150);
const [,,pages]=streamPdfPages(fs.readFileSync(source));const page=pages.next().value;
assert.equal(page.decision,'legacy');assert.equal(page.text,pre.expected);assert.equal(page.images.length,0);
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parser-normalize-'));const manager=new Manager({outputDir:dir});
try {for(const method of ['default','manual'])for(const output of ['txt','docx','pdf'])for(const applyCleanup of [false,true]){
  const r=await manager.dispatch({job:'extracting',method,output,inputKind:'pdf',inPath:source,filename:'legacy-page.pdf',applyCleanup,includeText:true});
  assert.equal(r.action,'parse');assert.equal(r.text,pre.expected,`${method}/${output}/${applyCleanup}`);assert.equal(r.pages,1);assert.ok(fs.statSync(r.file).size>0);assert.ok(!r.linearizationWarning);
  if(output==='txt')assert.ok(fs.readFileSync(r.file,'utf8').includes(pre.expected));
  if(output==='docx')assert.equal(extractDocxParagraphs(r.file).join('\n'),pre.expected);
  if(method==='manual')assert.deepEqual(r.ocrPages,[]);
  console.log(JSON.stringify({method,output,applyCleanup,bytes:fs.statSync(r.file).size,textChars:r.text.length,ocrPages:r.ocrPages??[]}));
}}finally{await manager.close();fs.rmSync(dir,{recursive:true,force:true});}
