import os, sys, json, subprocess, time
from pathlib import Path
import pikepdf
import pymupdf

ROOT=Path('/home/user/.cache/parser-eye/trash-broad')
REPO=Path('/home/user/Myangustis')
COMMIT='50c6b9a18ba0f8113fb485295dae87a2c9578f17'
raw=subprocess.check_output(['git','ls-tree','-r','-l','-z',COMMIT],cwd=REPO)
items=[]
for item in raw.split(b'\0'):
    if not item: continue
    header,name=item.split(b'\t',1)
    mode,kind,oid,size=header.split()
    name=name.decode('utf-8','surrogateescape')
    if not name.lower().endswith('.pdf'): continue
    items.append({'mode':mode.decode(),'kind':kind.decode(),'blob':oid.decode(),'bytes':int(size),'path':name})
assert len(items)==34
records=[]
for i,item in enumerate(items,1):
    st=time.monotonic(); record={'case':f'{i:02d}',**item,'status':'preparing'}
    source=ROOT/'sources'/f'{i:02d}.pdf'; sample=ROOT/'samples'/f'{i:02d}.pdf'
    try:
        if item['mode'] not in ('100644','100755') or item['kind']!='blob':
            raise ValueError('PDF entry is not a regular Git blob')
        with source.open('wb') as out:
            subprocess.run(['git','cat-file','blob',item['blob']],cwd=REPO,stdout=out,check=True)
        with pikepdf.open(source) as src:
            n=len(src.pages); take=min(n,10)
            record['source_pages']=n; record['selected_pages']=take
            if not take: raise ValueError('PDF contains zero pages')
            out=pikepdf.Pdf.new()
            for pg in src.pages[:take]:out.pages.append(pg)
            out.save(sample,object_stream_mode=pikepdf.ObjectStreamMode.disable)
        with pymupdf.open(source) as before,pymupdf.open(sample) as after:
            indices=sorted({0,take//2,take-1})
            render_matches=[]
            for j in indices:
                a=before[j].get_pixmap(matrix=pymupdf.Matrix(.5,.5),colorspace=pymupdf.csGRAY,alpha=False)
                b=after[j].get_pixmap(matrix=pymupdf.Matrix(.5,.5),colorspace=pymupdf.csGRAY,alpha=False)
                render_matches.append(a.width==b.width and a.height==b.height and a.samples==b.samples)
            record['sample_render_checked']=len(indices)
            record['sample_render_match']=all(render_matches)
            record['vector_text_pages']=sum(bool(after[j].get_text('text').strip()) for j in range(take))
            record['images_painted']=sum(len(after[j].get_image_info()) for j in range(take))
        record['sample_path']=str(sample);record['source_path']=str(source);record['sample_bytes']=sample.stat().st_size;record['status']='prepared'
    except Exception as e:
        record['status']='prepare-error';record['error']=f'{type(e).__name__}: {e}'
    record['prepare_seconds']=round(time.monotonic()-st,3)
    records.append(record)
    tmp=ROOT/'inventory.json.tmp';tmp.write_text(json.dumps({'commit':COMMIT,'cases':records},ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(ROOT/'inventory.json')
    print(json.dumps({k:record.get(k) for k in ('case','path','status','source_pages','selected_pages','sample_bytes','vector_text_pages','images_painted','sample_render_match','prepare_seconds','error')},ensure_ascii=False),flush=True)
print('PREPARED_ALL',len(records),flush=True)
