import fs from 'node:fs';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { streamPdfPages, loadDetector } from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
import { decryptPdf, expandObjectStreams, isEncryptedPdf, hasObjectStreams } from '/home/user/Myangustis/B.Parser/main/parser/read/decrypt.js';
import { FontResourceLoader } from '/home/user/Myangustis/B.Parser/main/parser/read/pdf-fonts.js';
import { Manager } from '/home/user/Myangustis/B.Parser/main/parser/manager.js';

const root='/home/user/.cache/parser-eye/trash-broad';
const id=String(process.argv[2]||'').padStart(2,'0');
const inventory=JSON.parse(fs.readFileSync(path.join(root,'inventory.json'),'utf8'));
const item=inventory.cases.find(x=>x.case===id);
if(!item)throw new Error(`Unknown case ${id}`);
const result={case:id,path:item.path,blob:item.blob,source_bytes:item.bytes,source_pages:item.source_pages,selected_pages:item.selected_pages,mode:'vector-text-default',sample_render_match:item.sample_render_match};
let activeTimings=null;
for(const method of ['pageFontResources','reversedFontCmap','tounicodeOf','cidToGid']){
  const original=FontResourceLoader.prototype[method];
  FontResourceLoader.prototype[method]=function(...args){
    if(!activeTimings)return original.apply(this,args);
    const at=performance.now();
    try{return original.apply(this,args);}finally{
      const v=activeTimings[method]??={calls:0,ms:0};v.calls++;v.ms+=performance.now()-at;
    }
  };
}
const ms=(n)=>Math.round(n*100)/100;
function breakdown(pages){
  const decisions={},paths={},warnings={};let chars=0,myanmar=0,markers=0,maxPrefix=0,blank=0,images=0,late=0;
  for(const pg of pages){
    decisions[pg.decision]=(decisions[pg.decision]||0)+1;
    paths[pg.parsingPath]=(paths[pg.parsingPath]||0)+1;
    for(const w of pg.warnings||[])warnings[w.code]=(warnings[w.code]||0)+1;
    chars+=pg.text.length;myanmar+=(pg.text.match(/[\u1000-\u109f]/gu)||[]).length;
    markers+=(pg.text.match(/\[[0-9A-F]{2,8}\]/g)||[]).length;
    maxPrefix=Math.max(maxPrefix,pg.checkpoint?.bytes||0);if(!pg.text.trim())blank++;
    images+=pg.images?.length||0;
    if(pg.warnings?.some(w=>['text-after-checkpoint','checkpoint-text-undecodable'].includes(w.code)))late++;
  }
  return {decisions,paths,warnings,chars,myanmar,bracket_hex_patterns:markers,max_prefix:maxPrefix,blank_pages:blank,image_placements:images,prefix_warnings:late};
}
async function probe(file,n,trackFonts){
  let start=performance.now(); let bytes=fs.readFileSync(file);const read=performance.now()-start;
  const encrypted=isEncryptedPdf(bytes),objects=hasObjectStreams(bytes);
  start=performance.now();if(encrypted)bytes=await decryptPdf(bytes);if(hasObjectStreams(bytes))bytes=await expandObjectStreams(bytes);const prep=performance.now()-start;
  const fontTimes={};activeTimings=trackFonts?fontTimes:null;
  start=performance.now();const [,num,iter]=streamPdfPages(bytes,loadDetector());const setup=performance.now()-start;
  const pages=[];const pageTimes=[];
  for(let i=0;i<n;i++){const at=performance.now();const row=iter.next();pageTimes.push(performance.now()-at);if(row.done)break;pages.push(row.value);}
  activeTimings=null;
  return {pages,metrics:{original_pages:num,read_ms:ms(read),decrypt_or_expand_ms:ms(prep),setup_ms:ms(setup),first_page_ms:ms(pageTimes[0]||0),all_page_ms:ms(pageTimes.reduce((a,b)=>a+b,0)),encrypted_marker:encrypted,object_stream_marker:objects,font_methods:Object.fromEntries(Object.entries(fontTimes).map(([k,v])=>[k,{calls:v.calls,ms:ms(v.ms)}])),...breakdown(pages)}};
}
let full=null,sample=null;
if(item.status!=='prepared'){
  result.status='prepare-error';result.error=item.error;
}else{
  try{
    full=await probe(item.source_path,item.selected_pages,true);
    result.full_source=full.metrics;
    result.full_source_over_default_input_limit=item.bytes>64*1024*1024;
  }catch(e){activeTimings=null;result.full_source_error=String(e?.message||e);}
  try{
    sample=await probe(item.sample_path,item.selected_pages,false);
    result.sample=sample.metrics;
    if(full){
      result.sample_vs_original_differences=full.pages.flatMap((p,i)=>sample.pages[i]?.text===p.text?[]:[i+1]);
    }
  }catch(e){activeTimings=null;result.sample_probe_error=String(e?.message||e);}
  if(global.gc)global.gc();
  const outPath=path.join(root,'results',`${id}.pdf`);const manager=new Manager({outputDir:path.dirname(outPath)});
  const start=performance.now();
  try{
    const reply=await manager.dispatch({job:'extracting',method:'default',output:'pdf',inputKind:'pdf',inPath:item.sample_path,
      filename:`${id} - ${path.basename(item.path)}`,outPath,applyCleanup:false,includeText:true},'site');
    result.manager_ms=ms(performance.now()-start);result.manager_pages=reply.pages;result.manager_counts=reply.counts;
    result.output_path=reply.file;result.output_bytes=fs.statSync(reply.file).size;result.encoding_path=reply.encodingPath;
    result.page_warnings=reply.pageWarnings||[];result.linearization_warning=reply.linearizationWarning||null;
    result.manager_text_matches_sample=sample?reply.text===sample.pages.map(x=>x.text).join('\n\n'):null;
    result.status=reply.pages===item.selected_pages&&!reply.linearizationWarning?'ok':'review';
  }catch(e){result.manager_ms=ms(performance.now()-start);result.status='manager-error';result.error=String(e?.message||e);}
  finally{await manager.close();}
}
fs.writeFileSync(path.join(root,'metrics',`${id}.json`),JSON.stringify(result,null,2));
console.log(JSON.stringify({case:id,path:item.path,status:result.status,source_pages:result.source_pages,selected:result.selected_pages,
 full_setup_ms:result.full_source?.setup_ms,full_first_ms:result.full_source?.first_page_ms,full_10_ms:result.full_source?.all_page_ms,
 full_font_methods:result.full_source?.font_methods,full_error:result.full_source_error,sample_error:result.sample_probe_error,
 full_sample_diffs:result.sample_vs_original_differences,manager_ms:result.manager_ms,output_bytes:result.output_bytes,
 manager_text_matches_sample:result.manager_text_matches_sample,sample_decisions:result.sample?.decisions,warnings:result.sample?.warnings,
 blank:result.sample?.blank_pages,markers:result.sample?.bracket_hex_patterns,error:result.error}));
