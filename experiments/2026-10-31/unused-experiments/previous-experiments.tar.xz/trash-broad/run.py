import json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path('/home/user/.cache/parser-eye/trash-broad'); REPO=Path('/home/user/Myangustis')
items=json.loads((ROOT/'inventory.json').read_text())['cases']
for item in items:
    case=item['case']; at=time.monotonic(); print(f'START case={case} path={item["path"]}',flush=True)
    try:
        r=subprocess.run(['node','--expose-gc',str(ROOT/'case.js'),case],cwd=REPO,capture_output=True,text=True,timeout=150)
        if r.stdout:print(r.stdout.strip(),flush=True)
        if r.returncode:
            print(json.dumps({'case':case,'fatal_exit':r.returncode,'stderr_tail':r.stderr[-3000:],'elapsed_seconds':round(time.monotonic()-at,2)}),flush=True)
            f=ROOT/'metrics'/f'{case}.json'
            if not f.exists():f.write_text(json.dumps({'case':case,'path':item['path'],'status':'fatal','error':r.stderr[-2000:]}))
    except subprocess.TimeoutExpired:
        print(json.dumps({'case':case,'fatal':'timeout','elapsed_seconds':round(time.monotonic()-at,2)}),flush=True)
        (ROOT/'metrics'/f'{case}.json').write_text(json.dumps({'case':case,'path':item['path'],'status':'timeout','error':'150 second per-case test timeout'}))
print('BATCH_ALL',len(items),flush=True)
