import fs from 'node:fs';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { streamPdfPages } from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
import { Manager } from '/home/user/Myangustis/B.Parser/main/parser/manager.js';
const root='/home/user/.cache/parser-eye/trash-broad';
const {cases}=JSON.parse(fs.readFileSync(`${root}/inventory.json`,'utf8'));
const dest=`${root}/default-results`;fs.mkdirSync(dest,{recursive:true});
const manager=new Manager({outputDir:dest});const records=[];
try{
 for(const item of cases){
  const id=item.case;const old=JSON.parse(fs.readFileSync(`${root}/metrics/${id}.json`,'utf8'));
  try{
   const [,num,iter]=streamPdfPages(fs.readFileSync(item.sample_path));const pages=[...iter];
   const expected=pages.map(p=>p.text).join('\n\n');const start=performance.now();
   // No applyCleanup property: this is the Manager's real default setting.
   const reply=await manager.dispatch({job:'extracting',method:'default',output:'pdf',inputKind:'pdf',inPath:item.sample_path,
    filename:`${id} - ${path.basename(item.path)}`,outPath:`${dest}/${id}.pdf`,includeText:true},'site');
   const row={case:id,status:'ok',manager_default_pages:reply.pages,seconds:Math.round((performance.now()-start)/10)/100,
     manager_default_matches_sample:reply.text===expected,
     manager_default_matches_previous_batch:old.manager_text_matches_sample===true&&reply.text===expected,
     manager_default_warnings_match:JSON.stringify(reply.pageWarnings||[])===JSON.stringify(old.page_warnings||[]),
     output:reply.file};
   if(reply.pages!==item.selected_pages||!row.manager_default_matches_previous_batch)row.status='review';
   records.push(row);console.log(JSON.stringify(row));
  }catch(e){const row={case:id,status:'error',error:String(e.stack||e)};records.push(row);console.log(JSON.stringify(row));}
 }
}finally{await manager.close();fs.writeFileSync(`${root}/manager-default-verification.json`,JSON.stringify(records,null,2));}
if(records.some(x=>x.status!=='ok'))process.exitCode=1;
