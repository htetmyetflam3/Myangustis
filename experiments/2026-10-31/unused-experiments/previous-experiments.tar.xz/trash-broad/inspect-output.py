import json, unicodedata
from pathlib import Path
import pymupdf
ROOT=Path('/home/user/.cache/parser-eye/trash-broad')
rows=[]
for f in sorted((ROOT/'metrics').glob('*.json')):
 m=json.loads(f.read_text());name=m.get('output_path')
 if not name:continue
 record={'case':m['case'],'output_pages':0,'visible_text_chars':0,'outside_page_chars':0,'pages_with_outside_text':0,'pages_majority_outside':0,'affected_pages':[]}
 with pymupdf.open(name) as doc:
  record['output_pages']=len(doc)
  for i,page in enumerate(doc):
   blocks=page.get_text('rawdict',clip=pymupdf.INFINITE_RECT())['blocks'];w,h=page.rect.width,page.rect.height
   chars=[ch for b in blocks if 'lines' in b for line in b['lines'] for span in line['spans'] for ch in span['chars']
          if ch['c'] and not ch['c'].isspace() and not unicodedata.category(ch['c'][0]).startswith('C')]
   outside=sum(not (0<=((c['bbox'][0]+c['bbox'][2])/2)<=w and 0<=((c['bbox'][1]+c['bbox'][3])/2)<=h) for c in chars)
   record['visible_text_chars']+=len(chars);record['outside_page_chars']+=outside
   if outside:record['pages_with_outside_text']+=1;record['affected_pages'].append({'page':i+1,'outside':outside,'total':len(chars)})
   if len(chars)>0 and outside>len(chars)/2:record['pages_majority_outside']+=1
 rows.append(record)
 print(json.dumps({k:v for k,v in record.items() if k!='affected_pages'}),flush=True)
(ROOT/'output-inspection.json').write_text(json.dumps(rows,indent=2))
print('INSPECTED_ALL',len(rows),flush=True)
