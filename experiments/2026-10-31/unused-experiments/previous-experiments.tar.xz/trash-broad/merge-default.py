import json,csv,collections,os
from pathlib import Path
import pymupdf
import pikepdf
ROOT=Path('/home/user/.cache/parser-eye/trash-broad')
PDF=Path('/home/user/parser-trash-results-default.pdf')
CSV=Path('/home/user/parser-trash-results-default.csv')
inv=json.loads((ROOT/'inventory.json').read_text())
items=inv['cases']; metrics={json.loads(x.read_text())['case']:json.loads(x.read_text()) for x in sorted((ROOT/'metrics').glob('*.json'))}
verification={x['case']:x for x in json.loads((ROOT/'manager-default-verification.json').read_text())}
for case, m in metrics.items():
 m['output_path']=str(ROOT/'default-results'/f'{case}.pdf')
 m['manager_ms']=verification[case]['seconds']*1000
 m['manager_text_matches_sample']=verification[case]['manager_default_matches_sample']
inspection={x['case']:x for x in json.loads((ROOT/'output-inspection.json').read_text())}
page_details=json.loads((ROOT/'page-details.json').read_text())
blank_review=json.loads((ROOT/'blank-page-review.json').read_text())
by_case=collections.defaultdict(list)
for row in page_details:by_case[row['case']].append(row)
merged=pymupdf.open(); cover=merged.new_page(width=595.28,height=841.89); toc=[]; summary=[]
for item in items:
 id=item['case'];m=metrics.get(id,{});o=inspection.get(id,{});s=m.get('sample',{}); warnings=s.get('warnings',{});
 start=merged.page_count+1
 out=m.get('output_path')
 if out and os.path.isfile(out):
  doc=pymupdf.open(out);out_pages=len(doc);merged.insert_pdf(doc);doc.close()
 else:
  page=merged.new_page(width=595.28,height=841.89);page.insert_text((45,60),f"Case {id} - Parser output unavailable",fontname='helv',fontsize=14);page.insert_text((45,90),str(m.get('error','No output file'))[:110],fontname='cour',fontsize=8);out_pages=1
 end=merged.page_count;toc.append([1,f"{id} - {Path(item['path']).name}",start])
 blanks=[r['page'] for r in by_case[id] if r['empty']]
 late=[r['page'] for r in by_case[id] if any(x['code']=='text-after-checkpoint' for x in r['warnings'])]
 undec=[r['page'] for r in by_case[id] if any(x['code']=='checkpoint-text-undecodable' for x in r['warnings'])]
 anywarnings='; '.join(f'{k}={v}' for k,v in sorted(warnings.items()))
 input_warnings=[]
 if id=='01' and item['bytes']>64*1024*1024:input_warnings.append('original exceeds the default 64 MiB Manager input limit; sampled input was tested')
 if id=='03':input_warnings.append('source page 1 title is visible Burmese but Parser emits bracket-hex markers')
 if id=='04':input_warnings.append('source page 3 has visible vector Burmese but Parser text is empty')
 if id=='24':input_warnings.append('source page 3 Burmese includes bracket-hex markers in Parser text')
 if id=='28':input_warnings.append('source page 5 mixes Zawgyi-One heading with WinInnwa body; shared route emits Latin-symbol gibberish for the body')
 if m.get('sample_vs_original_differences'):input_warnings.append('sample/full Parser text differs on pages '+','.join(map(str,m['sample_vs_original_differences'])))
 status='CHECK' if (warnings or blanks or s.get('bracket_hex_patterns') or o.get('pages_majority_outside',0) or input_warnings or m.get('status')!='ok') else 'OK'
 f=m.get('full_source',{}); fm=f.get('font_methods',{});font_ms=round(sum(v.get('ms',0) for v in fm.values()),2)
 summary.append({'case':id,'source_pdf':item['path'],'source_bytes':item['bytes'],'source_pages':item.get('source_pages'),
  'input_pages_tested':item.get('selected_pages'),'output_pdf_pages':out_pages,'merged_pdf_pages':f'{start}-{end}',
  'status':status,'manager_status':m.get('status'),'manager_reply_matches_page_parser':m.get('manager_text_matches_sample'),
  'manager_default_matches_previous_batch':verification[id]['manager_default_matches_previous_batch'],
  'full_original_vs_sample_page_text_match':not m.get('sample_vs_original_differences') and not m.get('full_source_error') and not m.get('sample_probe_error'),
  'original_read_ms':f.get('read_ms'),'original_decrypt_or_expand_ms':f.get('decrypt_or_expand_ms'),
  'original_parse_setup_ms':f.get('setup_ms'),'original_first_page_ms':f.get('first_page_ms'),'original_selected_pages_ms':f.get('all_page_ms'),
  'selected_font_loader_methods_total_ms':font_ms,'manager_default_sample_to_pdf_ms_approx':m.get('manager_ms'),
  'sample_render_matches_source':item.get('sample_render_match'),'maximum_checkpoint_bytes':s.get('max_prefix'),
  'pages_text_after_2048_bytes':','.join(map(str,late)),'pages_checkpoint_text_undecodable':','.join(map(str,undec)),
  'blank_parser_pages':','.join(map(str,blanks)),'pdf_pages_majority_nonspace_chars_off_page':o.get('pages_majority_outside',0),
  'pdf_offpage_nonspace_chars':o.get('outside_page_chars',0),'pdf_total_nonspace_chars':o.get('visible_text_chars',0),
  'bracket_hex_patterns_unverified':s.get('bracket_hex_patterns',0),'parser_warnings':anywarnings,'notes':'; '.join(input_warnings)})
# Index uses one page and bookmarks use the exact original output order.
cover=merged[0];cover.insert_text((30,34),'Parser output review - 34 text-based PDFs',fontname='helv',fontsize=15)
cover.insert_text((30,53),'First up to 10 pages. Manager default settings; no OCR. Actual generated PDFs.',fontname='helv',fontsize=9)
cover.insert_text((30,67),'CHECK marks warnings, blank extraction, or substantial off-page text; OK is not a correctness verdict.',fontname='helv',fontsize=8)
cover.insert_text((30,81),'Important: many generated lines are clipped; some fonts also produce unreadable text. See the CSV.',fontname='helv',fontsize=8)
cover.insert_text((30,99),'ID  IN  MERGED PAGES  CHECK  CLIP  FILE (bookmarks contain complete names)',fontname='cour',fontsize=8)
for i,row in enumerate(summary):
 name=Path(row['source_pdf']).name
 maxlen=56
 if len(name)>maxlen:name=name[:maxlen-3]+'...'
 text=f"{row['case']:>2}  {row['input_pages_tested']:>2}  {row['merged_pdf_pages']:<13} {row['status']:<5}  {row['pdf_pages_majority_nonspace_chars_off_page']:>2}/{row['output_pdf_pages']:<2}  {name}"
 cover.insert_text((30,116+i*18.5),text,fontname='cour',fontsize=7.3)
cover.insert_text((30,785),f"Snapshot: trash {inv['commit'][:12]}; generated PDFs are retypeset, not source pages.",fontname='helv',fontsize=8)
cover.insert_text((30,798),'CLIP = output pages with more than half of visible text characters outside the page.',fontname='helv',fontsize=8)
merged.set_toc(toc);merged.set_metadata({'title':'Parser output review - trash PDFs','subject':'First up to 10 pages per PDF; actual Parser output, vector path'})
merged.save(PDF,garbage=4,deflate=True,deflate_fonts=True);merged.close()
with CSV.open('w',encoding='utf-8',newline='') as fh:
 writer=csv.DictWriter(fh,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
with pikepdf.open(PDF) as q, pymupdf.open(PDF) as final:
 assert len(q.pages)==len(final);assert len(final)==1+sum(s['output_pdf_pages'] for s in summary)
 assert len(final.get_toc())==len(items)
 print(json.dumps({'pdf':str(PDF),'bytes':PDF.stat().st_size,'pdf_pages':len(final),'result_pages':len(final)-1,'bookmarks':len(toc),'csv':str(CSV),'csv_rows':len(summary)}))
# Independently compare every merged page's extractable content, including off-page text,
# and render the first and last page of each input output for pixel equivalence.
with pymupdf.open(PDF) as final:
 mismatched=[];render_mismatched=[];render_count=0
 for row in summary:
  item=metrics.get(row['case'],{});path=item.get('output_path');
  if not path or not os.path.isfile(path):continue
  begin=int(row['merged_pdf_pages'].split('-')[0])-1
  with pymupdf.open(path) as source:
   for j in range(len(source)):
    if source[j].get_text('text',clip=pymupdf.INFINITE_RECT())!=final[begin+j].get_text('text',clip=pymupdf.INFINITE_RECT()):mismatched.append([row['case'],j+1])
   for j in sorted({0,len(source)-1}):
    a=source[j].get_pixmap(matrix=pymupdf.Matrix(.55,.55),colorspace=pymupdf.csGRAY,alpha=False)
    b=final[begin+j].get_pixmap(matrix=pymupdf.Matrix(.55,.55),colorspace=pymupdf.csGRAY,alpha=False)
    render_count+=1
    if a.width!=b.width or a.height!=b.height or a.samples!=b.samples:render_mismatched.append([row['case'],j+1])
 print(json.dumps({'text_page_mismatches':mismatched,'rendered_page_checks':render_count,'render_mismatches':render_mismatched}))
 if mismatched or render_mismatched:raise SystemExit('Merged output did not preserve at least one result PDF page')
