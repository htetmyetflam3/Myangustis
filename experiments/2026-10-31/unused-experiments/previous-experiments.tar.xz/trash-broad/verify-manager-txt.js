import fs from 'node:fs';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { streamPdfPages } from '/home/user/Myangustis/B.Parser/extend/pipeline.js';
import { Manager } from '/home/user/Myangustis/B.Parser/main/parser/manager.js';
const root='/home/user/.cache/parser-eye/trash-broad';
const {cases}=JSON.parse(fs.readFileSync(`${root}/inventory.json`,'utf8'));
const old=Object.fromEntries(JSON.parse(fs.readFileSync(`${root}/manager-default-verification.json`,'utf8')).map(row=>[row.case,row]));
const dest=`${root}/default-text`;fs.mkdirSync(dest,{recursive:true});
const manager=new Manager({outputDir:dest});const records=[];
try{
 for(const item of cases){
  const id=item.case;
  try{
   const [,,iter]=streamPdfPages(fs.readFileSync(item.sample_path));const pages=[...iter];
   const expected=pages.map(p=>p.text).join('\n\n');const start=performance.now();
   const reply=await manager.dispatch({job:'extracting',method:'default',output:'txt',inputKind:'pdf',inPath:item.sample_path,
    filename:`${id} - ${path.basename(item.path)}`,outPath:`${dest}/${id}.txt`,includeText:true},'site');
   const row={case:id,status:'ok',manager_pages:reply.pages,matches_parser_pages:reply.text===expected,
     matches_pdf_reply:old[id].manager_default_matches_sample&&reply.text===expected,
     seconds:Math.round((performance.now()-start)/10)/100,output:reply.file};
   if(reply.pages!==item.selected_pages||!row.matches_pdf_reply)row.status='review';
   records.push(row);console.log(JSON.stringify(row));
  }catch(e){const row={case:id,status:'error',error:String(e.stack||e)};records.push(row);console.log(JSON.stringify(row));}
 }
}finally{await manager.close();fs.writeFileSync(`${root}/manager-txt-verification.json`,JSON.stringify(records,null,2));}
if(records.some(x=>x.status!=='ok'))process.exitCode=1;
